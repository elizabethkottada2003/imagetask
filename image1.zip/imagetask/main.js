const myButton = document.getElementById("myButton");

myButton.addEventListener("click", () => {
  // Code to execute when the button is clicked
  console.log("Button clicked!");
});